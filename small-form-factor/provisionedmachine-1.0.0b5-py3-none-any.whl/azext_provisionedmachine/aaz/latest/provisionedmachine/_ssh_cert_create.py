# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

# pylint: skip-file
# flake8: noqa

import os

from azure.cli.core.aaz import *
from azure.cli.core import azclierror
from azure.cli.core import telemetry
from azure.cli.core.style import Style, print_styled_text
from knack.log import get_logger

logger = get_logger(__name__)


@register_command(
    "provisionedmachine ssh-cert-create",
    is_preview=True,
)
class SshCertCreate(AAZCommand):
    """Create a short-lived SSH certificate for authenticating to a provisioned machine.

    Generates an SSH certificate signed by the device's CA key stored in
    Azure Key Vault. The certificate includes the caller's identity and
    role, and is valid for the duration of the active access window.

    Requires an active eligible role on the target device resource.
    The caller's identity and role are resolved automatically.

    :example: Create a certificate using default output paths
        az provisionedmachine ssh-cert-create --vault-name myKeyVault --resource-id /subscriptions/.../providers/Microsoft.AzureStackHCI/edgeMachines/myDevice

    :example: Create a certificate with custom output paths
        az provisionedmachine ssh-cert-create --vault-name myKeyVault --resource-id /subscriptions/.../providers/Microsoft.AzureStackHCI/edgeMachines/myDevice --private-key-path ~/.ssh/device_key --cert-path ~/.ssh/device_cert.pub
    """

    _args_schema = None

    @classmethod
    def _build_arguments_schema(cls, *args, **kwargs):
        if cls._args_schema is not None:
            return cls._args_schema
        cls._args_schema = super()._build_arguments_schema(*args, **kwargs)

        _args_schema = cls._args_schema

        _args_schema.vault_name = AAZStrArg(
            options=["-v", "--vault-name"],
            help="Name of the Azure Key Vault containing the SSH CA signing key.",
            required=True,
        )
        _args_schema.resource_id = AAZStrArg(
            options=["-r", "--resource-id"],
            help="Fully qualified ARM resource ID of the target device.",
            required=True,
        )
        _args_schema.cert_path = AAZStrArg(
            options=["--cert-path"],
            help="Output path for the signed SSH certificate file. "
                 "Defaults to a secure temporary directory if not specified.",
            required=False,
            default=None,
        )
        _args_schema.private_key_path = AAZStrArg(
            options=["--private-key-path"],
            help="Output path for the generated private key file. "
                 "Defaults to a secure temporary directory if not specified.",
            required=False,
            default=None,
        )

        return cls._args_schema

    def _handler(self, command_args):
        super()._handler(command_args)
        args = self.ctx.args

        vault_name = args.vault_name.to_serialized_data()
        resource_id = args.resource_id.to_serialized_data()
        cert_path = args.cert_path.to_serialized_data() if has_value(args.cert_path) else None
        private_key_path = args.private_key_path.to_serialized_data() if has_value(args.private_key_path) else None

        return self._execute_ssh_cert_create(vault_name, resource_id, cert_path, private_key_path)

    def _execute_ssh_cert_create(self, vault_name, resource_id, cert_path=None, private_key_path=None):
        """Create a short-lived SSH certificate for authenticating to a provisioned machine."""
        import shutil
        from azext_provisionedmachine import provisioned_machine_utils as pm

        cmd = self  # utility functions access cmd.cli_ctx

        telemetry.set_command_details('provisionedmachine ssh-cert-create')

        # Validate inputs.
        pm.validate_resource_id(resource_id)
        pm.validate_vault_name(vault_name)

        # Validate custom output paths if provided.
        if private_key_path:
            parent = os.path.dirname(os.path.abspath(private_key_path))
            if not os.path.isdir(parent):
                raise azclierror.InvalidArgumentValueError(
                    f"Directory '{parent}' does not exist. "
                    f"Please create it or use a different --private-key-path."
                )
        if cert_path:
            parent = os.path.dirname(os.path.abspath(cert_path))
            if not os.path.isdir(parent):
                raise azclierror.InvalidArgumentValueError(
                    f"Directory '{parent}' does not exist. "
                    f"Please create it or use a different --cert-path."
                )

        tmp_private_key_path = None
        tmp_cert_path = None
        try:
            # -- Step 1: Prepare -----------------------------------------------
            username = pm.get_current_user_principal(cmd)
            logger.info("Derived username: %s", username)

            # Verify the user has an active eligible role (JIT activated).
            _pim_instances, start_time, end_time = pm.check_pim_eligibility(cmd, resource_id)
            logger.info("Eligibility confirmed for resource: %s (valid %s to %s)",
                        resource_id, start_time, end_time)

            # Resolve role from assignment on the resource.
            role = pm.resolve_user_role(cmd, resource_id)
            logger.info("Resolved role: %s", role)

            # Extract device ID from resource ID.
            device_id = pm.extract_device_id(resource_id)
            logger.info("Device ID: %s", device_id)

            # Generate fresh ephemeral SSH key pair.
            tmp_private_key_path, public_key_path = pm.generate_ephemeral_keypair()

            certificate_metadata = {
                "username": username,
                "role": role,
                "deviceId": device_id,
                "startTime": start_time,
                "endTime": end_time,
                "publicKeyPath": public_key_path,
            }

            # -- Step 2: Sign -------------------------------------------------
            signed_certificate = pm.sign_certificate_metadata(
                cmd, vault_name, certificate_metadata
            )
            tmp_cert_path = signed_certificate["certificatePath"]

            # -- Step 3: Move to user-specified paths (if provided) -----------
            final_private_key = tmp_private_key_path
            final_cert = tmp_cert_path

            if private_key_path:
                shutil.copy2(tmp_private_key_path, private_key_path)
                import oschmod  # pylint: disable=import-outside-toplevel
                oschmod.set_mode(private_key_path, 0o600)
                final_private_key = os.path.abspath(private_key_path)

            if cert_path:
                shutil.copy2(tmp_cert_path, cert_path)
                import oschmod  # pylint: disable=import-outside-toplevel
                oschmod.set_mode(cert_path, 0o600)
                final_cert = os.path.abspath(cert_path)

            # Clean up temp files if user provided custom paths for both.
            if private_key_path and cert_path:
                pm.cleanup_ephemeral_files(tmp_private_key_path, tmp_cert_path)

            # -- Step 4: Return to user ----------------------------------------
            result = {
                "privateKeyPath": final_private_key,
                "certificatePath": final_cert,
            }

            print_styled_text((Style.SUCCESS,
                               f"SSH certificate created successfully.\n"
                               f"  Private key : {final_private_key}\n"
                               f"  Certificate : {final_cert}\n"
                               f"  Usage: ssh -i {final_private_key} "
                               f"-o CertificateFile={final_cert} "
                               f"{username}_jit@<device-hostname>"))

            if not (private_key_path and cert_path):
                logger.warning("The private key at %s is sensitive. "
                               "Delete it once the certificate expires.",
                               os.path.dirname(final_private_key))

            telemetry.set_success()
            return result

        except Exception:
            # Clean up sensitive ephemeral files on failure.
            pm.cleanup_ephemeral_files(tmp_private_key_path, tmp_cert_path)
            raise


__all__ = ["SshCertCreate"]
