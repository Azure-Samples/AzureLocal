Microsoft Azure Command-Line Tools ProvisionedMachine Extension - Manage Azure Stack HCI Edge Machines.
